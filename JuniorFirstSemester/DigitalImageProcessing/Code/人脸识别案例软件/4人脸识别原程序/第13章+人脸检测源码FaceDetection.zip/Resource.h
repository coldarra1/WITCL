//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FaceDetection.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_FACEDETYPE                  129
#define IDM_KROMO                       32771
#define IDM_DEVIOR                      32772
#define IDM_XPBLUE                      32773
#define ID_LIGHT                        32774
#define ID_SKINTONE                     32775
#define ID_DILATION_FIRST               32776
#define ID_ERASION                      32777
#define ID_DELETE_FALSE_AREA            32778
#define ID_DILATION                     32779
#define ID_ERASION_AGAIN                32780
#define ID_GET_FACE_AREA                32781
#define ID_EYE_Cr                       32782
#define ID_EYEMAPC                      32783
#define ID_EYEMAPL                      32784
#define ID_EYEMAP                       32785
#define ID_DELETE_FALSE_EYE             32786
#define ID_DILATION_EYE                 32787
#define ID_EYE_CENTER                   32788
#define ID_MOUSEMAP                     32789
#define ID_ERASION_MOUSE                32790
#define ID_DELETESCATER                 32791
#define ID_MOUTH_CENTER                 32792
#define ID_GOULE_FACE                   32793

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32794
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
