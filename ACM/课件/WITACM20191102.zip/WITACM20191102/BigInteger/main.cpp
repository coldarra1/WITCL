#include <iostream>
# include <algorithm>
# include "BigInt.h"

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
//	BigInt a;
//	std::cin >> a;
//	std::cout << a << std::endl;
//	BigInt b;
//	std::cin >> b;
//	std::cout << a + b << std::endl;
//	

	BigInt p[10];
	for (int i=0 ;i<10; i++) {
		std::cin >> p[i];
	}
	
	std::sort(p, p+10);
	
	for (int i=0; i<10; i++) {
		std::cout << p[i] << std::endl;
	}
	return 0;
}
