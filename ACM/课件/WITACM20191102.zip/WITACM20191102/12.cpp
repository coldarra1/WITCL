# include <iostream>
# include <set>

// �º���
struct mycompare {
	bool operator()	(int v1, int v2) {
		return v1 > v2;
	}
}; 

void test1() {
	std::set<int, mycompare> s1;
	
	s1.insert(54);
	s1.insert(82);
	s1.insert(20);
	s1.insert(20);
	
	for (std::set<int>::iterator it = s1.begin(); it!=s1.end(); it++) {
		std::cout << *it << " ";		
	}
	std::cout << std::endl; 
}

int main() {
	test1();
	
	return 0;
}
