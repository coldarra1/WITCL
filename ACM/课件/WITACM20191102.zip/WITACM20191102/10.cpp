# include <iostream>
# include <algorithm>
# include <list>

void test1() {
	std::list<int> mlist1;
	std::list<int> mlist2(10, 10);
	std::list<int> mlist3(mlist2);
	std::list<int> mlist4(mlist2.begin(), mlist2.end());
	
	for (std::list<int>::iterator it=mlist4.begin(); it!=mlist4.end(); it++) {
		std::cout << *it << std::endl;		
	}
} 

void test2() {
	std::list<int> mlist1;
	 
	mlist1.push_back(100);
	mlist1.push_front(200);
	
	// similiar to the push_front
	mlist1.insert(mlist1.begin(), 300);
	
	// similiar to the push_back
	mlist1.insert(mlist1.end(), 400);
	
	std::list<int>::iterator it = mlist1.begin(); 
	// it += 4; Error
	it++;
	it++;
	mlist1.insert(it, 500); 
	
	mlist1.pop_back();
	mlist1.pop_front();
	
	//claar
	//mlist1.erase(mlist1.begin(), mlist1.end());
	
	// delete all of the matched value
	mlist1.remove(500);     
	
	for (std::list<int>::iterator it=mlist1.begin(); it!=mlist1.end(); it++) {
		std::cout << *it << std::endl;		
	}
}

bool mycompare(int a, int b) {
	return a > b;
}

void test3() {
	std::list<int> mlist;
	mlist.assign(10, 8);
	
	std::list<int> mlist2;
	mlist2 = mlist;
	
	mlist2.swap(mlist);
	
	for (std::list<int>::iterator it=mlist2.begin(); it!=mlist2.end(); it++) {
		std::cout << *it << std::endl;		
	}  
	
	for (int i=0; i<6; i++) {
		mlist2.push_back(i);
	}
	
	std::cout << std::endl;
	for (std::list<int>::iterator it=mlist2.begin(); it!=mlist2.end(); it++) {
		std::cout << *it << std::endl;		
	}
	
	std::cout << std::endl;
//	std::sort(mlist2.b egin(), mlist2.end());    Error
	mlist2.sort();    // from small to big

	for (std::list<int>::iterator it=mlist2.begin(); it!=mlist2.end(); it++) {
		std::cout << *it << std::endl;		
	} 
	
	std::cout << std::endl;
	mlist2.sort(mycompare);    // from big to small
	for (std::list<int>::iterator it=mlist2.begin(); it!=mlist2.end(); it++) {
		std::cout << *it << std::endl;		
	} 
	
	// sort in <algorithm> is only support the vessel which support the random access	
}

int main() {
	//test1();
	//test2();
	test3();
	
	return 0;
}

