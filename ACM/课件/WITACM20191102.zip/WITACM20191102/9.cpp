# include <iostream>
# include <algorithm>
# include <list>

void test1() {
	std::list<int> mlist1;
	std::list<int> mlist2(10, 1);
	std::list<int> mlist3(mlist2);
	std::list<int> mlist4(mlist2.begin(), mlist2.end());
	
	for (std::list<int>::iterator it=mlist4.begin(); it!=mlist4.end(); it++) {
		std::cout << *it << std::endl;		
	}
} 

void test2() {
	std::list<int> mlist;
	
	mlist.push_back(100);
	mlist.push_front(200);
	mlist.pop_back();
	mlist.pop_front(); 
}

int main() {
	test1();
//	test2(); 
	
	return 0;
}
