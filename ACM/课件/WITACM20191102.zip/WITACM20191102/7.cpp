# include <iostream>
# include <cmath>

bool isPrime(int val) {
	int k = (int)sqrt(val);   
	
	int flag = k+1;
	for (int i=2; i<=k; i++) {
		if (0 == val%i) {
			flag = i;
			break;
		}
			
	}
	
	if (flag > k)
		return true;
	else
		return false;
}

int main() {
	int n;
	std::cin >> n;	 //std::cout << n << std::endl;
	
	int cnt;

	for(int i=2; i<=n; i++) {
        if (n % i == 0) {
            if (isPrime(i)) {
                cnt += i;     //std::cout << i << std::endl; 
            }
        }
    }
    
    if (cnt > 610) {
        std::cout << "a sdl wsl";
    } else {
        std::cout << "tcl";
    }

	return 0;
}
