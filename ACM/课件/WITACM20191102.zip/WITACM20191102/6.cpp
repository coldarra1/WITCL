# include <iostream>
# include <cstdio>
# include <cmath>

typedef long long ll;

const int INF1  =  0x3f3f3f3f;			// 4 pair of 3f 
const int NINF1 = -0x3f3f3f3f;
const ll INF2   =  0x3f3f3f3f3f3f3f3f;	// 8 pair of 3f
const ll NINF2  = -0x3f3f3f3f3f3f3f3f;	

const double PI = acos(-1);

int main() {
	std::cout << INF1 << " " << NINF1 << "\n";  
	std::cout << INF2 << " " << NINF2 << '\n';
	std::cout << PI << std::endl;
	
	return 0;
}

