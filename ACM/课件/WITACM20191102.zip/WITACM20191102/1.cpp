# include <iostream>
# include <iomanip>
# include <cmath>

int main() {
	double pi = acos(-1);
	double s = 1.989E30;
	double n = 42.0;
	
	// Set the precision.
	// std::cout << std::setprecision(4);
	
	// Default (i.e.general) format.
	std::cout << pi << std::endl;
	std::cout << s << std::endl;
	std::cout << n << std::endl << std::endl;
	
	// Fixed format.
	std::cout << std::fixed;
	std::cout << pi << std::endl;
	std::cout << s << std::endl;
	std::cout << n << std::endl << std::endl;
	
	// Secientific format.
	std::cout << std::scientific;
	std::cout << pi << std::endl;
	std::cout << s << std::endl;
	std::cout << n << std::endl << std::endl;
	
	// Reinstate general (i.e. not fixed or scientific) format.
	std::cout.unsetf(std::ios::fixed | std::ios::scientific);
	std::cout << pi << std::endl;
	
    return 0;
} 


