# include <iostream>
# include <cstdio>

template<class T>
void read(T &val) { 
	T x = 0; 
	int ng = 1; 
	char c; 
	
	for (c = getchar(); (c<'0' || c>'9') && c != '-'; c = getchar()); 
	
	if (c == '-') { 
		ng = -1; 
		c = getchar(); 
	}
	
	while (c >= '0' && c <= '9') {
		x = x * 10 + c - 48; 
		c = getchar();
	}
	
	val = x * ng; 
}

template<class T>
void put(T x){  
    static char	s[40];  	//20
    int bas = 0;  
  
    if(x < 0) {  
        putchar('-');  
        x = -x;  
    }  
    
    if(x == 0) {  
        putchar('0');  
        return;  
    }  

	while (x) {
		s[bas++] = x % 10 + '0';
		x /= 10;
	}
	 
	while (bas--) {
		putchar(s[bas]);
	}
}  

int main() {
	__int128 a;
	read(a);
//	std::cin >> a;
//	std::cout << a;
//	printf("%I128d\n", a);
	put(a);
	std::cout << "\n";
	
	return 0;
}

