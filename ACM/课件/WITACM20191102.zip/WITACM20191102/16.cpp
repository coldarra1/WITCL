# include <iostream>
# include <algorithm>
# include <cstring>

bool cmp(int x, int y) {
	return x > y;	
}

int main() {
//	int a[10] = {1, 22, 35, 25, 647, 35, 37, 39};
//	
//	std::sort(a, a+10, cmp);
//	
//	for (int i=0; i<10; i++) {
//		std::cout << a[i] << " ";
//	}
//	
//	std::cout << std::endl;
//	std::sort(a, a+10, std::less<int>());
//		for (int i=0; i<10; i++) {
//		std::cout << a[i] << " ";
//	}
//	
//	std::cout << std::endl; 
//	std::sort(a, a+10, std::greater<int>());
//	for (int i=0; i<10; i++) {
//		std::cout << a[i] << " ";
//	}	
	
	char s[100];
	std::cin >> s;
	std::sort(s, s+strlen(s), std::greater<char>());
	std::cout << s;
	
	// bigingeger
}

