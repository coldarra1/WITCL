# include <iostream>
# include <vector>

int main() {
//	int a[10] = {1};
//	for (int i=0; i<10; i++) {
//		std::cin >> a[i];
//	}
	
//	for (int i=0; i<10; i++) {
//		std::cout << a[i] << std::endl;
//	}
	
//	for (int *p=a; p!=a+10; p++) {
//		std::cout << *p << std::endl;
//	}
	
	std::vector<int> b;
	
//	for (int i=0; i<10; i++) {
//		std::cout <<  b[i];
//	}
	
//	for (int i=0; i<10; i++) {
//		std::cin >> b[i];
//	}
	
	b.resize(10);
//	std::cout << b[9]; 
	
	b.clear();
	std::cout << b.size() << std::endl;
	for (int i=0; i<10; i++) {
		b.push_back(i); 
	}
	
	for (int i=0; i<10; i++) {
		std::cout << b[i];
	}
	
	std::cout << b.size() << std::endl;
	
	for (std::vector<int>::iterator it=b.begin(); it!=b.end(); it++) {
		std::cout << *it << std::endl;
	}
	
	for(int i=0; i<b.size(); i++) {
		std::cout << b.at(i); 
	} 
	
	// std::for_each();
	
	return 0;
}
