# include <iostream>
# include <map>

void test1() {
	// key and value
	std::map<int, int> mymap;
	
	// pair.first key   pair.second value
	mymap.insert(std::pair<int, int> (10, 19)); 
	
	mymap.insert(std::make_pair(20, 12));
	
	mymap.insert(std::map<int, int>::value_type(2, 39));  
	
	mymap[0] = 40;
	
	for (std::map<int, int>::iterator it=mymap.begin(); it!=mymap.end(); it++) {
		std::cout << it->first << " ";
	}
}

void test2() {
	std::map<int, int> mymap;
	
	std::pair< std::map<int, int>::iterator, bool > ret = mymap.insert(std::pair<int, int> (10, 19)); 
	
	if (ret.second) {
		std::cout << "Success!" << std::endl;
	} else {
		std::cout << "Fail!" << std::endl;
	}
	
	ret = mymap.insert(std::pair<int, int> (10, 13)); 
	if (ret.second) {
		std::cout << "Success!" << std::endl;
	} else {
		std::cout << "Fail!" << std::endl;
	}
}

void test3() {
	std::map<int, int> mymap;
	
	mymap[2] = 12;
	mymap[0] = 90;
	mymap[30] = 20;
	
	for (std::map<int, int>::iterator it=mymap.begin(); it!=mymap.end(); it++) {
		std::cout << it->first << " " << it->second;		
		std::cout << std::endl;
	}
	
	std::cout << "--------------------------" << std::endl; 
	mymap[2] = 22;	// change the existed value
	for (std::map<int, int>::iterator it=mymap.begin(); it!=mymap.end(); it++) {
		std::cout << it->first << " " << it->second;		
		std::cout << std::endl;
	}	
	
	std::cout << "-------------------------" << std::endl;
	std::cout << "mymap[9] " << mymap[9] << std::endl;	// give a default value when asked
	for (std::map<int, int>::iterator it=mymap.begin(); it!=mymap.end(); it++) {
		std::cout << it->first << " " << it->second;
		std::cout << std::endl;		
	}
}

struct pair {
	int first;
	double second;
};

int main() {
//	test1();
//	test2();
//	test3();
	std::pair<int, double> p;
	p.first = 1;
	p.second = 1.5;
	std::cout << p.first << " " << p.second << std::endl;
	
	return 0;
}

