# include <iostream>
# include <set>

void test1() {
	std::set<int> s1;
	
	s1.insert(54);
	s1.insert(82);
	s1.insert(20);
	s1.insert(20);
	
	for (std::set<int>::iterator it = s1.begin(); it!=s1.end(); it++) {
		std::cout << *it << " ";		
	}
	std::cout << std::endl;
}

void test2() {
	std::set<int> s1;
	
	s1.insert(100);
	s1.insert(42);
	s1.insert(48);
	s1.insert(458);
	s1.insert(648);
	s1.insert(288);
	
	s1.erase(s1.begin());
	s1.erase(458);   
	
	for (std::set<int>::iterator it = s1.begin(); it!=s1.end(); it++) {
		std::cout << *it << " ";		
	}
	std::cout << std::endl;	
	
	std::cout << *s1.begin() << std::endl;
	std::cout << *s1.end()-- << std::endl; 
	std::cout << *s1.rbegin() << std::endl;
}

void test3() {
	std::set<int> s1;
	
	s1.insert(100);
	s1.insert(42);
	s1.insert(48);
	s1.insert(458);
	s1.insert(648);
	s1.insert(288);

	std::cout << "------------------------" << std::endl;	
	std::set<int>::iterator it = s1.find(42); 
	if (it == s1.end()) {
		std::cout << "Not Found!" << std::endl; 
	} else {
		std::cout << *it << std::endl;
	}
	
	std::cout << "------------------------" << std::endl;
	it = s1.find(45); 
	if (it == s1.end()) {
		std::cout << "Not Found!" << std::endl; 
	} else {
		std::cout << *it << std::endl;
	}
	
	std::cout << "------------------------" << std::endl;
	// Find the iterator not less than the num  
	it = s1.lower_bound(99);
	if (it == s1.end()) {
		std::cout << "Not Found!" << std::endl; 
	} else {
		std::cout << *it << std::endl;
	}
	
	std::cout << "------------------------" << std::endl;
	// Find the iterator bigger than the num  
	it = s1.upper_bound(100);
	if (it == s1.end()) {
		std::cout << "Not Found!" << std::endl; 
	} else {
		std::cout << *it << std::endl;
	}

	std::cout << "------------------------" << std::endl;
	// return two value: lower_bound and the upper_bound 
	std::pair< std::set<int>::iterator, std::set<int>::iterator > pairit = s1.equal_range(100); 
	if (pairit.first == s1.end()) {
		std::cout << "Not Found!" << std::endl; 
	} else {
		std::cout << *(pairit.first) << std::endl;
	}	
	
	if (pairit.second == s1.end()) {
		std::cout << "Not Found!" << std::endl; 
	} else {
		std::cout << *(pairit.second) << std::endl;
	}		
}

int main() {
//	test1();
	test2();
	//test3(); 
	
	return 0;
}
