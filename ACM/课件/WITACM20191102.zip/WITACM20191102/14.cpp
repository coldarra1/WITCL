# include <iostream>
# include <map>

class MyKey {
public:
	MyKey(int index, int id);
	
	int mIndex;
	int mID;
};

MyKey::MyKey(int index, int id) {
	this->mIndex = index;
	this->mID = id;
} 

struct mycompare {
	bool operator() (const MyKey &key1, const MyKey &key2) {
		return key1.mIndex > key2.mIndex;
	}
};

void test1() {
	std::map<MyKey, int, mycompare> mymap;
	mymap.insert(std::make_pair(MyKey(1, 2), 10)); 
	mymap.insert(std::make_pair(MyKey(4, 5), 0));
	
	for (std::map<MyKey, int, mycompare>::iterator it=mymap.begin(); it!=mymap.end(); it++) {
		std::cout << it->first.mIndex << " " << it->first.mID << std::endl;
	}
}

void test2() {
	std::map<int, int> mymap;
	mymap.insert(std::make_pair(1, 4));
	mymap.insert(std::make_pair(2, 5));
	mymap.insert(std::make_pair(3, 6));
	
	std::pair<std::map<int, int>::iterator,  std::map<int, int>::iterator> ret = mymap.equal_range(2);
	if (ret.first->second) {
		std::cout << "Find the lower_bound!" << std::endl;
	} else {
		std::cout << "Not find the lower_bound!" << std::endl;
	}
	
	if (ret.second->second) {
		std::cout << "Find the upper_bound!" << std::endl;
	} else {
		std::cout << "Not find the upper_bound!" << std::endl;
	}
}

struct pair {
	int first;
	double second;
};

int main() {
	//test1();
	//test2();
	pair p1;
	p1.first = 1;
	p1.second = 1.5;
	
	
	return 0;
}
