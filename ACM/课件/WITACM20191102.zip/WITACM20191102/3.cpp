# include <iostream>
# include <cstdio>

int main() {
	std::ios::sync_with_stdio(false);
	std::cin.tie(NULL);		// std::cin.tie(0);
	std::cout.tie(NULL); 	// std::cout.tie(0);
	
	int T;
	std::cin >> T;
	int a[10];
	
	for (int i=0; i<T; i++) {
		std::cin >> a[i];
		std::cout << a[i] << std::endl;
	}
	
	return 0;
}
